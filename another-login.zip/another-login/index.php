<?php
if(isset($_GET['name']) && isset($_GET['mail']) && isset($_GET['pass'])){
  $name = $_GET['name'];
  $mail = $_GET['mail'];
  $pass = $_GET['pass'];

  // Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get form data
$name = $_POST['txt'];
$email = $_POST['email'];
$password = $_POST['pswd'];

// Insert data into table
$sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>