const read = () =>{
var nameInput = document.getElementById("name");
var nameValue = nameInput.value;
//nameValue is the val
var emailInput = document.getElementById("email");
var emailValue = emailInput.value;
//emailValue is the val
var passInput = document.getElementById("pass");
var passValue = passInput.value;
//nameValue is the val
document.location.href = "./index.php?name=" + nameValue + "&mail=" + emailValue + "&pass"
}